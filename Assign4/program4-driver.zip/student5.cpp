///////////////////////////////////////////////////////////////////
// Student name: 
// Course: COSC 4553 - Information Security
// Assignment: Assignment #5 - RSA Key Generation
// File name:   
// Purpose: Defines the functions that generate the RSA public and
//          private keys
// Limitations:  
// Development Computer:   
// Operating System: 
// Integrated Development Environment (IDE): 
// Compiler:  
// Build Directions: See the driver module
// Operational Status: 
///////////////////////////////////////////////////////////////////

#include <iostream>
#include "RSA_Keys.h"

using namespace std;




// ##################################################################
void generateKeys(int primeA, int primeB, int &encryptionExponent, 
                  int &decryptionExponent)
{

encryptionExponent = 1;
decryptionExponent = 1;

} // End generateKeys


